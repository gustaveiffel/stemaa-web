
  # Personal Page with Contact Form

  This is a code bundle for Personal Page with Contact Form. The original project is available at https://www.figma.com/design/99aMsRmOFkQJwNI0PiFSDl/Personal-Page-with-Contact-Form.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  